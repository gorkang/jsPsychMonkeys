# ADMIN -------------------------------------------------------------------

# See jsPsychHelper/admin/000_CHECK_canonical.R
# Check trialids, repeated names, etc.

# pak::pak("gorkang/jsPsychMonkeys")

# SETUP -------------------------------------------------------------------

  # First time
  # source("setup.R")
  # If it fails, open _targets_packages.R, install all the packages there and rerun setup.R

  # ~/Downloads NEEDS write permissions for all users [NOT SAFE]

  # See the jsPsychR-manual for details
  # https://gorkang.github.io/jsPsychR-manual/qmd/02-QuickGuide.html#setup


# targets::tar_meta() |> View()
# SET PARAMETERS ----------------------------------------------------------

  # Define protocol parameters in _targets.R:
    # rstudioapi::navigateToFile("_targets.R")
    # e.g. `local_folder_tasks` = WHERE is the local protocol?


# Clean up ----------------------------------------------------------------

  # Stop all monkeys docker containers
  jsPsychMonkeys::clean_monkeys_containers()


  # Delete targets cache
  targets::tar_destroy(ask = FALSE)


# Launch  -----------------------------------------------------------------

  targets::tar_make() # Single CPU

  targets::tar_make_future(workers = future::availableCores() - 2) # Parallel. All minus 2 CPU's available
  targets::tar_make_future(workers = 10) # Parallel. All minus 2 CPU's available

  # Clean up
  targets::tar_destroy(ask = FALSE)

# Watch -------------------------------------------------------------------

  targets::tar_watch(seconds = 5, outdated = FALSE, targets_only = TRUE) #, exclude = "parameters_monkeys"

  targets::tar_visnetwork(targets_only = TRUE)




# TESTING -----------------------------------------------------------------

  # Stop all monkeys docker containers
  jsPsychMonkeys::clean_monkeys_containers()


  # Delete targets cache
  targets::tar_destroy(ask = FALSE)

  targets::tar_watch(seconds = 5, outdated = FALSE, targets_only = TRUE) #, exclude = "parameters_monkeys"
  targets::tar_make() # Single CPU
  targets::tar_make_future(workers = 2) # Parallel. All minus 2 CPU's available

  jsPsychMonkeys::reconnect_to_VNC(container_name = "monkey_test")

