# jsPsychMonkeys 0.2.0

Major updates  


* Works with jsPsychMaker 0.2.0
* Working with ~60 tasks
* Added new parameter `forced_random_wait` so the Monkeys wait a random amount (to get over max_time)
* Added new parameter `forced_seed` so the Monkeys' behavior is reproducible
* Added new parameter `forced_refresh` so the Monkeys restart the protocol (to check they continue in the task where they left off)
* 
